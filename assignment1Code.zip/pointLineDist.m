function [ d, g ] = pointLineDist( p, x0, x1, J0, J1 )
%pointLineDist Returns square of thedistance between a point and a line 
%   Returns the distance between the point p and the line segment between
%   x0 and x1 if p, x0, and x1 are all in R3. Also returns gradient
%   of the distance given the jacobians of the points x0 and x1

t = (p - x0)' * (x1 - x0);

if t < 0
    d = (p - x0)'*(p - x0);
    g = 2 * J0' * (p - x0); 
elseif t > (x1 - x0)'*(x1 - x0)
    d = (p - x1)'*(p - x1);
    g = 2 * J1' * (p - x1);
else
    p0 = p - x0;
    p1 = p - x1;
    numer = (cross(p0, p1)'*cross(p0, p1));
    denom = ((x1 - x0)'*(x1 - x0));
    d = numer / denom;
    gradNumer = 2*(crossMatrix(p1)*J0 - crossMatrix(p0)*J1)'*cross(p0, p1);
    gradDenom = 2 * (J1 - J0)' * (x1 - x0);
    g = (gradNumer * denom - numer * gradDenom) / denom^2;
end
end

