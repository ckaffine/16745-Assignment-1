function [ Ax ] = crossMatrix( a )
%crossMatrix returns the skew-symmetric matrix representing the cross
% product by a

Ax = [0 -a(3) a(2); a(3) 0 -a(1); -a(2) a(1) 0];


end

