function [pos, R, Js, JR] = fk( r, p, y )
% do forward kinematics of a snake robot

global linkLengths;

pos = zeros(3, size(linkLengths, 1) + 1);
transformations = repmat(eye(4), 1, 1, size(linkLengths, 1) + 1);
Js = zeros(3, size(r, 1)*3, size(linkLengths, 1));
JR = zeros(9, size(r, 1)*3);

for i = 1:size(linkLengths, 1)
    yawMat = [cos(y(i)) -sin(y(i)) 0; sin(y(i)) cos(y(i)) 0; 0 0 1];
    pitchMat = [cos(p(i)) 0 sin(p(i)); 0 1 0; -sin(p(i)) 0 cos(p(i))];
    rollMat = [1 0 0; 0 cos(r(i)) -sin(r(i)); 0 sin(r(i)) cos(r(i))];
    rot = [yawMat*pitchMat*rollMat zeros(3, 1); zeros(1, 3) 1];
    trans = [1 0 0 linkLengths(i); 0 1 0 0; 0 0 1 0; 0 0 0 1];
    transformations(:, :, i+1) = transformations(:, :, i) * rot * trans;
    pos(:, i+1) = transformations(1:3, 4, i+1);
end

R = transformations(1:3, 1:3, end);

for i = 1:size(linkLengths, 1)
    yawMat = [cos(y(i)) -sin(y(i)) 0; sin(y(i)) cos(y(i)) 0; 0 0 1];
    pitchMat = [cos(p(i)) 0 sin(p(i)); 0 1 0; -sin(p(i)) 0 cos(p(i))];
    yawAxis = transformations(1:3, 1:3, i) * [0; 0; 1];
    pitchAxis = transformations(1:3, 1:3, i) * yawMat * [0; 1; 0];
    rollAxis = transformations(1:3, 1:3, i) * yawMat * pitchMat * [1; 0; 0];
    JR(:, i) = reshape(crossMatrix(rollAxis)*R, [9 1]);
    JR(:, size(linkLengths, 1)+i) = reshape(crossMatrix(pitchAxis)*R, [9 1]);
    JR(:, 2*size(linkLengths, 1)+i) = reshape(crossMatrix(yawAxis)*R, [9 1]);
    for j = i+1:size(linkLengths, 1)+1
        r = pos(:, j) - pos(:, i);
        Js(:, i, j) = cross(rollAxis, r);
        Js(:, size(linkLengths, 1) + i, j) = cross(pitchAxis, r);
        Js(:, 2*size(linkLengths, 1) + i, j) = cross(yawAxis, r);
    end
end


end
