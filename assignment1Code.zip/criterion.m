function [score, grad] = criterion(j)
%%% optimization criterion: x is vector of joint angles

global minRoll maxRoll minPitch maxPitch minYaw maxYaw linkLengths;
global goal orientation spheres repeats

numLinks = size(j, 1) / 3;
r = j(1:numLinks);
p = j(numLinks+1:2*numLinks);
y = j(2*numLinks+1:3*numLinks);

% do graphics
[pos, R, Js, JR] = draw(r, p, y);
x = pos(:, end);

goalScore = (x(1:3) - goal)'*(x(1:3) - goal);
goalGrad = 2 * Js(:, :, end)' * (x(1:3) - goal);
rotScore = sum(reshape(eye(3) - R*orientation', [9 1]).^2);
rotGradThing = -2 * reshape(eye(3) - R*orientation', [9 1]);
rotGrad = zeros(3*size(r, 1), 1);
for i = 1:3*size(r, 1)
    rotGrad(i) = rotGradThing' * reshape(reshape(JR(:, i), [3 3])* ...
                                         orientation', [9 1]);
end
          
minAngles = [minRoll; minPitch; minYaw];
maxAngles = [maxRoll; maxPitch; maxYaw];
if size(find(j < minAngles), 1) > 0 || size(find(j > maxAngles), 1) > 0
    limitScore = nan;
else
    limitScore = sum(1./(j - minAngles)) + sum(1./(maxAngles - j));
end
limitGrad = 1./(maxAngles - j).^2 - 1./(j - minAngles).^2;
 
interiorPenalty = 1e9;
obstacleScore = 0;
obstacleGrad = 0;
for sphereNum = size(spheres, 1)
    sphere = spheres(sphereNum, :);
    smallestDist = -1;
    gradient = 0;
    for i = 1:size(pos, 1)-1
        [d, g] = pointLineDist(sphere(1:3)', pos(:, i), pos(:, i+1), ...
                               Js(:, :, i), Js(:, :, i+1));
        if smallestDist == -1 || d < smallestDist
            smallestDist = d;
            gradient = g;
        end
    end
    if smallestDist < sphere(4)^2
        obstacleScore = obstacleScore + interiorPenalty;
    else
        obstacleScore = obstacleScore + 1/(sqrt(smallestDist)-sphere(4));
        obstacleGrad = obstacleGrad - 1/(sqrt(smallestDist)-sphere(4))^2*...
                                      gradient/(2*sqrt(smallestDist));
    end
end

repeatScore = 0;
repeatGrad = 0;
for i = 1:size(repeats, 2)
    d = j - repeats(i);
    repeatScore = repeatScore + 1 / (d'*d);
    repeatGrad = repeatGrad - 2 * d ./ (d'*d).^2;
end

scale = sum(linkLengths);
score = 10*goalScore/scale^2 + rotScore + ...
        .005*limitScore + .005*scale*obstacleScore + .5*repeatScore;
    
grad = 10*goalGrad/scale^2 + rotGrad + ...
       .005*limitGrad + .005*scale*obstacleGrad + .5*repeatGrad;

% final end
end
