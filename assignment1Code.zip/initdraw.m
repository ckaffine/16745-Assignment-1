global h_axes links

scrsz = get(0,'ScreenSize');
animation = figure(1);

color0 = [0 0 0];
color1 = [1 0 0];
color2 = [0 0 1];
color3 = [0 1 0];
color4 = [1 0 1];

set(animation,'name','My Robot');
h_axes = axes('Parent',animation,'Units','Pixels');

numLinks = size(linkLengths, 1);
pos = fk(p0(1:numLinks), p0(numLinks+1:2*numLinks), p0(2*numLinks+1:3*numLinks));

[x, y, z] = sphere;
hold on;
for i = 1:size(spheres, 1)
    i
    surf(x*spheres(i, 4) + spheres(i, 1), ...
         y*spheres(i, 4) + spheres(i, 2), ...
         z*spheres(i, 4) + spheres(i, 3), ...
         'Parent', h_axes, 'FaceColor', color3, 'EdgeColor', color0);
end
line([0 target(1)], [0 target(2)], [0 target(3)], 'Color', color2);
links = line(pos(1, :), pos(2, :), pos(3, :), ...
             'Parent',h_axes,'Color',color1,'LineWidth',1);
axis([-3 3 -3 3 -3 3]);

set(h_axes,'visible','on');
