function [pos, q, J, JR] = draw( r, p, y )
global links;

% do forward kinematics of snake robot and draw result
[pos, q, J, JR] = fk(r, p, y);

set(links, 'visible','on', ...
    'Xdata', pos(1, :), ...
    'Ydata', pos(2, :), ...
    'Zdata', pos(3, :));
drawnow
% delay
 for j = 1:1000000
   z = sin(sqrt(100.0*j));
 end

end
